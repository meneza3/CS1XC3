/**
 * @file course.h
 * @author Andre Menezes - meneza3
 * @brief This file contains the typedef struct for Course and the
 *         function definitions used in the file course.c
 * @version 0.1
 * @date 2022/04/11
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "student.h"
#include <stdbool.h>
 
/**
 * @brief This is the Course type. It is responsible for storing the 
 *        course name, course code, students enrolled in the course,
 *        and the total number of students enrolled.
 * 
 */ 
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

// Function definitions
void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);