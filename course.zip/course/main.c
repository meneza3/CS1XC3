/**
 * @mainpage Courses & Students
 * @file main.c
 * @author Andre Menezes - meneza3
 * @brief The file main.c allows assingning students to a certain course,
 *        finding the top student on a course, and visualizing students that 
 *        have passed the course.
 * @version 0.1
 * @date 2022/04/11
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * @brief Begins by creating a course where students are allowed to enroll.
 *        Uses the function generate_random_student to generate random students,
 *        and the function enroll_student to enroll each student. Next, the 
 *        print_course function is used to print out information on the course.
 *        The top student of the course is then determined by using the top_student
 *        function. Lastly, the total number of passing students and the respective
 *         students are printed.
 * 
 * 
 * 
 * @return int As all being values are being printed, the function returns 0. As 0 
 *         does not affect anything, it can be assumed that nothing is returned.
 */

int main()
{
  srand((unsigned) time(NULL));

  // Memory allocation for courses using calloc
  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  // Generating students
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);

  // Assinging a top student the top_student variable
  // Printing out the top student
  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  // Assigning the number of students passing to the total_passing variable
  // Printing out the total number of students passing
  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}