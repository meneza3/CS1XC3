/**
 * @file student.c
 * @author Andre Menezes - meneza3
 * @brief This file contains functions that can be used to add a grade to a
 *        student, calculate student's average, print out student's information,
 *        and generate random students.
 * @version 0.1
 * @date 2022/04/11
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * @brief The function add_grade is used to add a grade to a student. Memory allocation
 *        is done using calloc if the student only has one grade. Else, realloc is used
 *        to reallocate memory.
 * 
 * @param student Parameter representing the student chosen
 * @param grade Parameter representing the student's grade
 * @return void
 */
void add_grade(Student* student, double grade)
{
  student->num_grades++;
  // Base case where student only has one grade
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  // If number of grades is greater than one
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  student->grades[student->num_grades - 1] = grade;
}

/**
 * @brief The function average can be used to calculate the average grade of a student. The
 *        initial condition is that if the student does not have any grades, his averga grade
 *        is 0. Else, a for loop is used to iterate through the student's grades, adding them
 *        together and dividing the total sum of grades by the number of grades to get the 
 *        average.
 * 
 * @param student Parameter representing the student chosen
 * @return double Returns average grade of type double
 */
double average(Student* student)
{
  if (student->num_grades == 0) return 0;

  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  return total / ((double) student->num_grades);
}

/**
 * @brief The function print_student is used to print out information about a given student.  
 *        Once the function is used, the student's name, ID, grades, and average is printed.
 * 
 * @param student Parameter representing the student chosen
 * @return void
 */
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/**
 * @brief The function generate_random_student is used to created random students, where their
 *        name and last name come from two different lists. After generating the student the 
 *        function then assigns grades to the student using the add_grade function inside a for
 *        loop.
 * 
 * @param grades Parameter representing the student's grades
 * @return Student* Student of type Student
 */
Student* generate_random_student(int grades)
{
  // List of first name for random generator
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};
  // List of last name for random generator
  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  Student *new_student = calloc(1, sizeof(Student));

  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  // Generating random student ID
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}