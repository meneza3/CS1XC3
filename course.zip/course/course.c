/**
 * @file course.c
 * @author Andre Menzes - meneza3
 * @brief This file contains functions that can be used to control and
 *        visualize content dealing with students and courses. These can
 *        enroll stundets into courses, print out informations about a
 *        course, the top student in a course, and the passing students
 *        in a course.
 * @version 0.1
 * @date 2022/04/11
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * @brief The function enroll_student is used to enrolll students into a 
 *        course and keep track of the current total number of students
 *        enrolled in the course. The function calloc is used to add an
 *        extra student to the course, while the realloc function is used
 *        to update the memory allocation for the total number of students
 *        in a course.
 * 
 * @param course Parameter representing the course chosen
 * @param student Parameter representing the student chosen
 * @return void
 */ 
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief The function print_course is used to print out the course name,
 *        course code, total number of students enrolled in the course, and
 *        information about each student using the print_student function.
 * 
 * @param course Parameter representing the course chosen
 * @return void
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief The function top_student is used to find the top student enrolled in
 *        a course. The top student is the student with the highest grade 
 *        average. The variable student_average is used to keep track of the
 *        current stundent's average which will then be compared to the value
 *        stored in the max_average variable. If the student's average is greater
 *        than the max average value, max_average is then set to be student_average
 *        and the student with the highest average is also updated. The for loop is
 *        responsible for repeating the process until there are no students left. 
 * 
 * @param course Parameter representing the course chosen
 * @return Student* Function returns the student with the highest average in the course
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief The function passing is used to find all the students who are passing a course. If
 *        the student has an average greater than or equal to 50, the student passes the course.
 *        The function uses for loops to iterate through all students, find their average and 
 *        determine whether they passed or not.
 * 
 *        The first loop uses calloc to allocate the quantity of memory necessary for the passing
 *        pointer variable. While the second loop is only used to assign the respctive values to 
 *        the passing variable.
 * 
 * @param course Parameter representing the course chosen
 * @param total_passing Parameter representing the total number of students passing
 * 
 * @return Student* Function returns the name of students are passing the course and including all
 *         other information associated to the student
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student));

  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}